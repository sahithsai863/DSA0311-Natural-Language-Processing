# ResearchIQ Core Backend

Install dependencies:
`pip install -r requirements.txt`

Run:
`uvicorn main:app --reload`

API documentation:
`http://127.0.0.1:8000/docs`

Included:
- OpenAlex academic search with Sentence Transformers semantic reranking
- PDF text extraction using PyMuPDF
- TF-IDF extractive summarization
- Structured section detection
- Paper comparison using embedding cosine similarity
- Candidate research direction endpoint
- In-memory saved-paper library

This is a compact backend demonstration, not the complete application in the master specification. It does not include the React frontend, PostgreSQL persistence, authentication, OCR, background jobs, or full page-level evidence citations. The saved-paper library resets when the server restarts. Candidate research gaps require human verification. Test all dependencies and endpoints in your environment before claiming full functionality.
