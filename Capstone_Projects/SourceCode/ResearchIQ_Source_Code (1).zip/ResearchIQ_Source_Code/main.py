from typing import List, Optional
import re
import httpx
import fitz
from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel, Field
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer

app = FastAPI(title="ResearchIQ API", version="1.0.0")
encoder = SentenceTransformer("all-MiniLM-L6-v2")
library = []

class SearchRequest(BaseModel):
    query: str = Field(min_length=3)
    limit: int = Field(default=10, ge=1, le=50)

class Paper(BaseModel):
    title: str
    abstract: str = ""
    authors: List[str] = Field(default_factory=list)
    year: Optional[int] = None
    source: str = "Uploaded"
    url: Optional[str] = None

class CompareRequest(BaseModel):
    papers: List[Paper] = Field(min_length=2, max_length=5)

def normalize(text):
    return re.sub(r"\\s+", " ", text or "").strip()

def encode_and_rank(query, records):
    if not records:
        return []
    documents = [normalize(x.get("title", "") + ". " + x.get("abstract", "")) for x in records]
    vectors = encoder.encode([query] + documents, normalize_embeddings=True)
    scores = cosine_similarity([vectors[0]], vectors[1:])[0]
    output = []
    for record, score in zip(records, scores):
        item = dict(record)
        item["semantic_similarity"] = round(float(score), 4)
        output.append(item)
    return sorted(output, key=lambda x: x["semantic_similarity"], reverse=True)

async def search_openalex(query, limit):
    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.get("https://api.openalex.org/works", params={"search": query, "per-page": limit})
        response.raise_for_status()
    works = response.json().get("results", [])
    results = []
    for work in works:
        inverted = work.get("abstract_inverted_index") or {}
        positions = {position: word for word, indexes in inverted.items() for position in indexes}
        abstract = " ".join(positions[i] for i in sorted(positions))
        results.append({
            "title": work.get("title") or "Untitled",
            "abstract": abstract,
            "authors": [a.get("author", {}).get("display_name", "") for a in work.get("authorships", [])],
            "year": work.get("publication_year"),
            "source": "OpenAlex",
            "url": work.get("doi") or work.get("id"),
            "open_access": work.get("open_access", {}).get("is_oa")
        })
    return results

def extract_pdf(content):
    doc = fitz.open(stream=content, filetype="pdf")
    pages = [f"Page {i + 1}: {normalize(page.get_text())}" for i, page in enumerate(doc)]
    doc.close()
    return "\n".join(x for x in pages if x.strip())

def summarize(text, count=7):
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\\s+", normalize(text)) if len(s.split()) > 5]
    if not sentences:
        return "Not enough readable text to summarize."
    if len(sentences) <= count:
        return " ".join(sentences)
    matrix = TfidfVectorizer(stop_words="english").fit_transform(sentences)
    scores = matrix.sum(axis=1).A1
    selected = sorted(sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:count])
    return " ".join(sentences[i] for i in selected)

def section_analysis(text):
    patterns = {
        "research_problem": r"problem statement|research problem|motivation",
        "methodology": r"methodology|methods|proposed method|approach",
        "findings": r"results|findings|experiments",
        "limitations": r"limitations|threats to validity",
        "future_work": r"future work|future directions"
    }
    lines = text.splitlines()
    result = {}
    for key, pattern in patterns.items():
        match = next((i for i, line in enumerate(lines) if re.search(pattern, line, re.I)), None)
        result[key] = normalize(" ".join(lines[match:match + 5]))[:1000] if match is not None else "Not identified in extracted text."
    return result

@app.get("/api/v1/health")
def health():
    return {"status": "healthy", "application": "ResearchIQ"}

@app.post("/api/v1/papers/search")
async def search(request: SearchRequest):
    try:
        candidates = await search_openalex(request.query, request.limit)
        return {"query": request.query, "results": encode_and_rank(request.query, candidates)}
    except httpx.HTTPError:
        raise HTTPException(status_code=502, detail="Academic search provider is unavailable.")

@app.post("/api/v1/documents/analyze")
async def analyze_pdf(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".pdf") or file.content_type != "application/pdf":
        raise HTTPException(status_code=400, detail="Upload a PDF file.")
    content = await file.read()
    if len(content) > 15 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="PDF exceeds 15 MB.")
    try:
        text = extract_pdf(content)
    except Exception:
        raise HTTPException(status_code=400, detail="PDF is invalid, encrypted, or unreadable.")
    if len(text) < 100:
        raise HTTPException(status_code=422, detail="Insufficient selectable text. OCR may be required.")
    return {"filename": file.filename, "summary": summarize(text), "analysis": section_analysis(text), "text_preview": text[:2000]}

@app.post("/api/v1/comparisons")
def compare(request: CompareRequest):
    texts = [normalize(p.title + ". " + p.abstract) for p in request.papers]
    vectors = encoder.encode(texts, normalize_embeddings=True)
    matrix = cosine_similarity(vectors)
    return {
        "papers": [p.model_dump() for p in request.papers],
        "semantic_similarity_matrix": [[round(float(v), 4) for v in row] for row in matrix],
        "note": "Text similarity does not prove that experimental results are directly comparable."
    }

@app.post("/api/v1/research-gaps/analyze")
def research_gaps(request: CompareRequest):
    evidence = [{"paper": p.title, "abstract_or_evidence": p.abstract or "No abstract supplied; inspect the full paper."} for p in request.papers]
    corpus = " ".join(p.abstract for p in request.papers if p.abstract)
    terms = []
    if corpus:
        terms = TfidfVectorizer(stop_words="english", max_features=10).fit([corpus]).get_feature_names_out().tolist()
    return {
        "evidence": evidence,
        "recurring_terms": terms,
        "potential_direction": "Review the papers' stated limitations and future-work sections to formulate a research question.",
        "verification": "These are candidate directions from the selected papers, not proven gaps in all existing literature."
    }

@app.post("/api/v1/library")
def save_paper(paper: Paper):
    library.append(paper.model_dump())
    return {"saved": True, "count": len(library)}

@app.get("/api/v1/library")
def get_library():
    return {"count": len(library), "papers": library}
